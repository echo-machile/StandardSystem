import React, {useEffect, useState} from 'react';
import {Upload, Button, Input, Form, Row, Col, Modal} from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import { post } from '@/utils/request';
import axios from "axios";
import parseJson from "parse-json";

const FileUploadForm = (props) => {
  const { visible, setVisible,actionRef } = props;
  // useEffect(()=>setVisible(props.visible),[props])
  const [selectedFile, setSelectedFile] = useState(null);
  const onFinish = async (values) => {
    console.log('Received values of form: ', values);
    if (selectedFile) {
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('industry', values.industry);
      formData.append('category', values.category);

      try {
        const response = await axios.post('/standard/upload', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
            token: sessionStorage.getItem("token"),
          },
        });
        console.log('文件和数据已发送到后端并保存');
      } catch (error) {
        console.log('文件和数据发送到后端时出错：', error);
      }
    } else {
      console.log('请先选择一个文件');
    }
  };

  const [form] = Form.useForm();

  const fileUploadProps = {
    name: 'file',
    action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76', // 替换为您的文件上传API接口
    headers: {
      authorization: 'authorization-text',
    },
    // onChange(info) {
    //     if (info.file.status !== 'uploading') {
    //       console.log(info.file, info.fileList);
    //     }
    //     if (info.file.status === 'done') {
    //       console.log(`${info.file.name} 上传成功`);
    //
    //       // 获取文件内容
    //       const file = info.file.originFileObj;
    //       const reader = new FileReader();
    //       reader.readAsDataURL(file);
    //       reader.onload = () => {
    //         // 发送文件内容到后端
    //         post('/upload', {
    //           filename: info.file.name,
    //           fileContent: reader.result
    //         })
    //           .then((response) => {
    //             console.log('文件已发送到后端并保存');
    //           })
    //           .catch((error) => {
    //             console.log('文件发送到后端时出错：', error);
    //           });
    //       };
    //       reader.onerror = (error) => {
    //         console.log('文件读取失败:', error);
    //       };
    //
    //     } else if (info.file.status === 'error') {
    //       console.log(`${info.file.name} 上传失败`);
    //     }
    //   },
    beforeUpload(file) {
      setSelectedFile(file);
      return false; // 阻止默认的文件上传处理
    },
  };
  const handleUpload = () => {
    form.submit();
    setVisible(false)
    actionRef();
  };
  return (
    <div>
      <Modal open={visible} onOk={handleUpload} onCancel={()=>{setVisible(false);}}>
          <Form layout="vertical" onFinish={onFinish} form={form} >
            <Row gutter={16}>
              <Col span={12}>
                <Form.Item
                  name="industry"
                  label="行业"
                  rules={[{ required: true, message: '请输入行业' }]}
                >
                  <Input placeholder="请输入行业" />
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item
                  name="category"
                  label="标准类别"
                  rules={[{ required: true, message: '请输入标准类别' }]}
                >
                  <Input placeholder="请输入标准类别" />
                </Form.Item>
              </Col>
            </Row>
            <Form.Item label="上传文件">
              <Upload {...fileUploadProps}>
                <Button icon={<UploadOutlined />}>点击上传</Button>
              </Upload>
            </Form.Item>

          </Form>
        </Modal>
    </div>


);
};

export default FileUploadForm;
