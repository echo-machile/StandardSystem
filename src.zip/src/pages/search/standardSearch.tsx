import React, {Component, useEffect, useRef, useState} from 'react';
import {createFromIconfontCN, MinusCircleTwoTone, PlusCircleTwoTone, SearchOutlined} from "@ant-design/icons";
import { Upload, Button, message, Input ,Space,Row,Col,Form} from 'antd';
import type { InputRef } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import ProTable from '@ant-design/pro-table';
import {post,get} from "@/utils/request";
import FileUploadForm from "@/pages/search/uploadForm";
import {ProColumns} from "@ant-design/pro-components";
import {request} from "@umijs/max";
import style from "./standardSearch.less"
// const MyIcon = createFromIconfontCN({
//   scriptUrl: '//at.alicdn.com/t/font_3357165_ia0k1ycbbif.js', // 在 iconfont.cn 上生成
// });

// <MyIcon type="icon-shezhi" style={{ fontSize: "30px" }} onClick={this.showModal} />

interface DataType {
  key: number;
  name: string;
  age: number;
  address: string;
}

const StandardSearch: React.FC = () => {
  const [fileList, setFileList] = useState<any[]>([]);
  const [searchText, setSearchText] = useState('');
  const [data, setData] = useState<DataType[]>([]);
  const [uploadVisible,setVisible] = useState(false);
  const actionRef = useRef();
  const columns: ProColumns<DataType>[] = [
    {
      title: 'id',
      dataIndex: 'id',
      key: 'id',

    },
    {
      title: '书名',
      dataIndex: 'documentName',
      key: 'documentName',
    },
    {
      title: '行业',
      dataIndex: 'industry',
      key: 'industry',
    },
    {
      title: '分类',
      dataIndex: 'standardCategory',
      key: 'standardCategory',
    },
    {
      title: '内容',
      dataIndex: 'content',
      key: 'content',
      width:200,
      ellipsis: true,
      tooltip:false,
    },
  ];
  useEffect(()=> {
    get("/showTable").then(data=>{
      setData(data.data);
      console.log(data);
    })
  },[])
  const handleChange = (info: any) => {
    let fileList = [...info.fileList];

    fileList = fileList.slice(-1);

    setFileList(fileList);
    post("/upload",{
      file: fileList,
    }).then(data =>{
      console.log(data)
    })
  };


  const handleSearch2 = (value: string) => {
    console.log(value);
  };

  const handleUpload = () => {
    setVisible(true);
  };

  const fetchData = async (params) => {
    // 向后端发送请求，传递参数
    const response = await request('/standard/getContent', {
      method: 'POST',
      headers:{
        "token": sessionStorage.getItem("token")
      },
      data: {
        id: params.id,
        content: params.content,
        documentName: params.documentName,
        industry: params.industry,
        current: params.current,
        pagesize: params.pagesize,
        standardCategory: params.standardCategory,
      },
    }).then((result)=>{
      return setData(result);
    });

    return {
      data: response.data, // 表格数据
      success: true,
      total: response.total, // 数据总数
    };
  };


  return (
    <div style={style}>
      <Button icon={<UploadOutlined/>} onClick={()=>{handleUpload();}}>上传文件</Button>
      <FileUploadForm visible={uploadVisible} setVisible={setVisible} actionRef={()=>{actionRef.current?.reload();}}></FileUploadForm>

      <ProTable<DataType>

        columns={columns}
        dataSource={data}
        actionRef={actionRef}
        rowKey={(record) => record.id}
        search={{
          labelWidth: 'auto',
        }}
        request={fetchData}
        pagination={{
          pageSize: 10,
        }}
        // expandable={{
        //   expandedRowRender: (record) => <p style={{ margin: 0 }}>{record.content}</p>,
        //   rowExpandable: (record) => record.name !== 'Not Expandable',
        //
        // }}

        expandable={{
          expandedRowRender: record => (
            <p style={{ margin: 0 }}>{record.content}</p>
          ),
          expandIcon: ({ expanded, onExpand, record }) =>
            expanded ? (
              <MinusCircleTwoTone onClick={e => onExpand(record, e)} />
            ) : (
              <PlusCircleTwoTone onClick={e => onExpand(record, e)} />
            )
        }}
        dateFormatter="string"
        headerTitle="标准查询表"
        style={{ marginTop: 10 }}
      />
    </div>
  );
};

export default StandardSearch;

